import datetime
import validators


# Custom Cerberus validators
def is_func(field, value, error):
    j2_func = [
        "rh",
        "cmd-rh",
        "noc",
        "cmd-noc",
        "expand-noc",
        "core",
        "cmd-core",
        "expand-core",
        "note",
        "jumper",
    ]
    if value not in j2_func:
        error(field, f"Must be one of {j2_func}")


def is_24h(field, value, error):
    if len(str(value)) < 4:
        error(field, "Must be in 24h format")


def is_date(field, value, error):
    if value != "today":
        if type(value) != datetime.date:
            error(field, 'Must be in YYYY-MM-DD format or "today"')


def is_url(field, value, error):
    try:
        if not validators.url(value):
            error(field, "Must be a valid url")
    except TypeError:
        pass
