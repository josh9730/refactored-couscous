# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['mops', 'mops.schemas']

package_data = \
{'': ['*'], 'mops': ['defaults/*', 'renderers/*']}

install_requires = \
['Cerberus>=1.3.4,<2.0.0',
 'PyYAML>=6.0,<7.0',
 'argparse>=1.4.0,<2.0.0',
 'atlassian-python-api>=3.14.0,<4.0.0',
 'cerebrus>=0.2,<0.3',
 'google-api-core>=2.0.1,<3.0.0',
 'google-api-python-client>=2.23.0,<3.0.0',
 'google-auth-httplib2>=0.1.0,<0.2.0',
 'google-auth-oauthlib>=0.4.6,<0.5.0',
 'google-auth>=2.2.1,<3.0.0',
 'googleapis-common-protos>=1.53.0,<2.0.0',
 'jinja2>=3.0.1,<4.0.0',
 'keyring>=23.2.1,<24.0.0',
 'pyotp>=2.6.0,<3.0.0',
 'validators>=0.18.2,<0.19.0']

setup_kwargs = {
    'name': 'mops',
    'version': '0.2.2',
    'description': 'Create MOPs and CDs',
    'long_description': None,
    'author': 'Josh Dickman',
    'author_email': None,
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.7,<4.0',
}


setup(**setup_kwargs)
